package example;

public class ReadfromExternalFile {
}
